﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class dangky
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_trove = New System.Windows.Forms.Button()
        Me.btn_dangky = New System.Windows.Forms.Button()
        Me.txt_password = New System.Windows.Forms.TextBox()
        Me.txt_username = New System.Windows.Forms.TextBox()
        Me.lbl_mk = New System.Windows.Forms.Label()
        Me.lbl_tendangnhap = New System.Windows.Forms.Label()
        Me.lbl_dangky = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btn_trove
        '
        Me.btn_trove.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btn_trove.Font = New System.Drawing.Font("Times New Roman", 10.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.btn_trove.Location = New System.Drawing.Point(392, 288)
        Me.btn_trove.Margin = New System.Windows.Forms.Padding(2)
        Me.btn_trove.Name = "btn_trove"
        Me.btn_trove.Size = New System.Drawing.Size(107, 38)
        Me.btn_trove.TabIndex = 19
        Me.btn_trove.Text = "TRỞ VỀ"
        Me.btn_trove.UseVisualStyleBackColor = False
        '
        'btn_dangky
        '
        Me.btn_dangky.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btn_dangky.Font = New System.Drawing.Font("Times New Roman", 10.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.btn_dangky.Location = New System.Drawing.Point(239, 288)
        Me.btn_dangky.Margin = New System.Windows.Forms.Padding(2)
        Me.btn_dangky.Name = "btn_dangky"
        Me.btn_dangky.Size = New System.Drawing.Size(107, 38)
        Me.btn_dangky.TabIndex = 18
        Me.btn_dangky.Text = "ĐĂNG KÝ"
        Me.btn_dangky.UseVisualStyleBackColor = False
        '
        'txt_password
        '
        Me.txt_password.Location = New System.Drawing.Point(239, 183)
        Me.txt_password.Margin = New System.Windows.Forms.Padding(2)
        Me.txt_password.Multiline = True
        Me.txt_password.Name = "txt_password"
        Me.txt_password.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txt_password.Size = New System.Drawing.Size(294, 22)
        Me.txt_password.TabIndex = 17
        '
        'txt_username
        '
        Me.txt_username.Location = New System.Drawing.Point(239, 114)
        Me.txt_username.Margin = New System.Windows.Forms.Padding(2)
        Me.txt_username.Multiline = True
        Me.txt_username.Name = "txt_username"
        Me.txt_username.Size = New System.Drawing.Size(294, 22)
        Me.txt_username.TabIndex = 15
        '
        'lbl_mk
        '
        Me.lbl_mk.AutoSize = True
        Me.lbl_mk.Font = New System.Drawing.Font("Times New Roman", 13.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.lbl_mk.Location = New System.Drawing.Point(28, 183)
        Me.lbl_mk.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbl_mk.Name = "lbl_mk"
        Me.lbl_mk.Size = New System.Drawing.Size(118, 22)
        Me.lbl_mk.TabIndex = 14
        Me.lbl_mk.Text = "PASSWORD"
        '
        'lbl_tendangnhap
        '
        Me.lbl_tendangnhap.AutoSize = True
        Me.lbl_tendangnhap.Font = New System.Drawing.Font("Times New Roman", 13.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.lbl_tendangnhap.Location = New System.Drawing.Point(28, 114)
        Me.lbl_tendangnhap.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbl_tendangnhap.Name = "lbl_tendangnhap"
        Me.lbl_tendangnhap.Size = New System.Drawing.Size(119, 22)
        Me.lbl_tendangnhap.TabIndex = 13
        Me.lbl_tendangnhap.Text = "USERNAME"
        '
        'lbl_dangky
        '
        Me.lbl_dangky.AutoSize = True
        Me.lbl_dangky.Font = New System.Drawing.Font("Times New Roman", 13.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.lbl_dangky.Location = New System.Drawing.Point(295, 31)
        Me.lbl_dangky.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbl_dangky.Name = "lbl_dangky"
        Me.lbl_dangky.Size = New System.Drawing.Size(98, 22)
        Me.lbl_dangky.TabIndex = 11
        Me.lbl_dangky.Text = "ĐĂNG KÝ"
        '
        'dangky
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(670, 419)
        Me.Controls.Add(Me.btn_trove)
        Me.Controls.Add(Me.btn_dangky)
        Me.Controls.Add(Me.txt_password)
        Me.Controls.Add(Me.txt_username)
        Me.Controls.Add(Me.lbl_mk)
        Me.Controls.Add(Me.lbl_tendangnhap)
        Me.Controls.Add(Me.lbl_dangky)
        Me.Name = "dangky"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btn_trove As Button
    Friend WithEvents btn_dangky As Button
    Friend WithEvents txt_password As TextBox
    Friend WithEvents txt_username As TextBox
    Friend WithEvents lbl_mk As Label
    Friend WithEvents lbl_tendangnhap As Label
    Friend WithEvents lbl_dangky As Label
End Class

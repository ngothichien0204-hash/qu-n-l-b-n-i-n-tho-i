﻿Imports System.Data.SqlClient
Imports System.Net
Public Class dangnhap
    Private Sub dangnhap_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btn_dangnhap_Click(sender As Object, e As EventArgs) Handles btn_dangnhap.Click
        Dim con As New SqlConnection("Data Source=NGUYNTHNHNA4447\SA;Initial Catalog=bandienthoai;Persist Security Info=True;User ID=sa;Password=Konodioda2006@@;TrustServerCertificate=True")
        Dim cmd As New SqlCommand("SELECT * FROM Dangky WHERE Username = @user AND Password = @pass", con)
        cmd.Parameters.AddWithValue("@user", txt_dangnhap.Text.Trim())
        cmd.Parameters.AddWithValue("@pass", txt_matkhau.Text.Trim())

        Dim da As New SqlDataAdapter(cmd)
        Dim dt As New DataTable()

        Try
            con.Open()
            da.Fill(dt)

            If dt.Rows.Count > 0 Then
                Dim tenDangNhap As String = dt.Rows(0)("Username").ToString()
                MessageBox.Show("Đăng nhập thành công! Xin chào " & tenDangNhap)

                Dim mainForm As New main()
                mainForm.Show()
                Me.Hide()
            Else
                MessageBox.Show("Tên đăng nhập hoặc mật khẩu không đúng!")
            End If
        Catch ex As Exception
            MessageBox.Show("Lỗi kết nối: " & ex.Message)
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub btn_dangky_Click(sender As Object, e As EventArgs) Handles btn_dangky.Click
        Me.Hide()
        dangky.ShowDialog()
        Me.Show()
    End Sub
End Class
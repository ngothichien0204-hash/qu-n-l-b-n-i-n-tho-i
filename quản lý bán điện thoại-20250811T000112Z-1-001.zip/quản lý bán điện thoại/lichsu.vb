﻿Imports System.Data
Imports System.Data.SqlClient
Public Class lichsu
    Private connectionString As String = "Data Source=NGUYNTHNHNA4447\SA;Initial Catalog=bandienthoai;Persist Security Info=True;User ID=sa;Password=Konodioda2006@@;TrustServerCertificate=True"
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub lichsu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        HienThiDonHang()
    End Sub
    Private Sub HienThiDonHang()
        Using conn As New SqlConnection(connectionString)
            Try
                conn.Open()

                ' Chuẩn bị câu lệnh SQL để lấy toàn bộ dữ liệu từ bảng DonHang
                Dim sql As String = "SELECT * FROM DonHang"

                ' Sử dụng SqlDataAdapter để điền dữ liệu vào DataTable
                Using da As New SqlDataAdapter(sql, conn)
                    Dim dt As New DataTable()
                    da.Fill(dt)

                    ' Gán DataTable vào DataGridView để hiển thị dữ liệu
                    dgvDonHang.DataSource = dt

                    ' Tự động điều chỉnh kích thước cột
                    dgvDonHang.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells
                End Using
            Catch ex As Exception
                MessageBox.Show("Lỗi khi tải dữ liệu: " & ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
    End Sub

End Class
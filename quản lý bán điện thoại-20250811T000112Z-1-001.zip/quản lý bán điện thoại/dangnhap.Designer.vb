﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class dangnhap
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_dangky = New System.Windows.Forms.Button()
        Me.btn_dangnhap = New System.Windows.Forms.Button()
        Me.txt_matkhau = New System.Windows.Forms.TextBox()
        Me.txt_dangnhap = New System.Windows.Forms.TextBox()
        Me.LBL_pass = New System.Windows.Forms.Label()
        Me.lbl_username = New System.Windows.Forms.Label()
        Me.lbl_dangnhap = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btn_dangky
        '
        Me.btn_dangky.BackColor = System.Drawing.SystemColors.ControlDark
        Me.btn_dangky.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.btn_dangky.Location = New System.Drawing.Point(231, 232)
        Me.btn_dangky.Margin = New System.Windows.Forms.Padding(2)
        Me.btn_dangky.Name = "btn_dangky"
        Me.btn_dangky.Size = New System.Drawing.Size(100, 31)
        Me.btn_dangky.TabIndex = 13
        Me.btn_dangky.Text = "ĐĂNG KÝ"
        Me.btn_dangky.UseVisualStyleBackColor = False
        '
        'btn_dangnhap
        '
        Me.btn_dangnhap.BackColor = System.Drawing.SystemColors.ControlDark
        Me.btn_dangnhap.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.btn_dangnhap.Location = New System.Drawing.Point(231, 187)
        Me.btn_dangnhap.Margin = New System.Windows.Forms.Padding(2)
        Me.btn_dangnhap.Name = "btn_dangnhap"
        Me.btn_dangnhap.Size = New System.Drawing.Size(100, 31)
        Me.btn_dangnhap.TabIndex = 12
        Me.btn_dangnhap.Text = "ĐĂNG NHẬP"
        Me.btn_dangnhap.UseVisualStyleBackColor = False
        '
        'txt_matkhau
        '
        Me.txt_matkhau.Location = New System.Drawing.Point(211, 144)
        Me.txt_matkhau.Margin = New System.Windows.Forms.Padding(2)
        Me.txt_matkhau.Multiline = True
        Me.txt_matkhau.Name = "txt_matkhau"
        Me.txt_matkhau.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txt_matkhau.Size = New System.Drawing.Size(342, 26)
        Me.txt_matkhau.TabIndex = 11
        '
        'txt_dangnhap
        '
        Me.txt_dangnhap.Location = New System.Drawing.Point(211, 86)
        Me.txt_dangnhap.Margin = New System.Windows.Forms.Padding(2)
        Me.txt_dangnhap.Multiline = True
        Me.txt_dangnhap.Name = "txt_dangnhap"
        Me.txt_dangnhap.Size = New System.Drawing.Size(342, 26)
        Me.txt_dangnhap.TabIndex = 10
        '
        'LBL_pass
        '
        Me.LBL_pass.AutoSize = True
        Me.LBL_pass.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LBL_pass.Location = New System.Drawing.Point(61, 149)
        Me.LBL_pass.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LBL_pass.Name = "LBL_pass"
        Me.LBL_pass.Size = New System.Drawing.Size(96, 19)
        Me.LBL_pass.TabIndex = 9
        Me.LBL_pass.Text = "MẬT KHẨU"
        '
        'lbl_username
        '
        Me.lbl_username.AutoSize = True
        Me.lbl_username.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.lbl_username.Location = New System.Drawing.Point(61, 86)
        Me.lbl_username.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbl_username.Name = "lbl_username"
        Me.lbl_username.Size = New System.Drawing.Size(104, 19)
        Me.lbl_username.TabIndex = 8
        Me.lbl_username.Text = "USER NAME"
        '
        'lbl_dangnhap
        '
        Me.lbl_dangnhap.AutoSize = True
        Me.lbl_dangnhap.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.lbl_dangnhap.Location = New System.Drawing.Point(227, 44)
        Me.lbl_dangnhap.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbl_dangnhap.Name = "lbl_dangnhap"
        Me.lbl_dangnhap.Size = New System.Drawing.Size(104, 19)
        Me.lbl_dangnhap.TabIndex = 7
        Me.lbl_dangnhap.Text = "ĐĂNG NHẬP"
        '
        'dangnhap
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(624, 365)
        Me.Controls.Add(Me.btn_dangky)
        Me.Controls.Add(Me.btn_dangnhap)
        Me.Controls.Add(Me.txt_matkhau)
        Me.Controls.Add(Me.txt_dangnhap)
        Me.Controls.Add(Me.LBL_pass)
        Me.Controls.Add(Me.lbl_username)
        Me.Controls.Add(Me.lbl_dangnhap)
        Me.Name = "dangnhap"
        Me.Text = "dangnhap"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_dangky As Button
    Friend WithEvents btn_dangnhap As Button
    Friend WithEvents txt_matkhau As TextBox
    Friend WithEvents txt_dangnhap As TextBox
    Friend WithEvents LBL_pass As Label
    Friend WithEvents lbl_username As Label
    Friend WithEvents lbl_dangnhap As Label
End Class

﻿Imports System.Data
Imports System.Data.SqlClient

Public Class quanlydienthoai
    ' Chuỗi kết nối đầy đủ và đúng cú pháp
    Private connectionString As String = "Data Source=NGUYNTHNHNA4447\SA;Initial Catalog=bandienthoai;Persist Security Info=True;User ID=sa;Password=Konodioda2006@@;TrustServerCertificate=True"

    Private Sub quanlydienthoai_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadDienThoai()
    End Sub

    Private Sub LoadDienThoai()
        Using conn As New SqlConnection(connectionString)
            Try
                conn.Open()
                Dim sql As String = "SELECT MaDienThoai, TenDienThoai, HangSanXuat, GiaBan, SoLuongTon, MoTa, NgayNhap, BaoHanh FROM DienThoai"
                Using da As New SqlDataAdapter(sql, conn)
                    Dim dt As New DataTable()
                    da.Fill(dt)
                    dgvDienThoai.DataSource = dt
                    dgvDienThoai.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells
                End Using
            Catch ex As Exception
                MessageBox.Show("Lỗi khi tải dữ liệu: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
    End Sub

    Private Sub btnthem_Click(sender As Object, e As EventArgs) Handles btnthem.Click
        Try
            Dim tenDT As String = InputBox("Nhập tên điện thoại:")
            If tenDT = "" Then Exit Sub

            Dim hangSX As String = InputBox("Nhập hãng sản xuất:")
            If hangSX = "" Then Exit Sub

            Dim giaStr As String = InputBox("Nhập giá bán:")
            If Not IsNumeric(giaStr) Then
                MessageBox.Show("Giá bán phải là số.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            Dim giaBan As Decimal = Decimal.Parse(giaStr)

            Dim soLuongStr As String = InputBox("Nhập số lượng tồn:")
            If Not IsNumeric(soLuongStr) Then
                MessageBox.Show("Số lượng tồn phải là số nguyên.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            Dim soLuongTon As Integer = Integer.Parse(soLuongStr)

            Dim moTa As String = InputBox("Nhập mô tả (có thể bỏ qua):")

            Dim ngayNhapStr As String = InputBox("Nhập ngày nhập (yyyy-MM-dd):")
            Dim ngayNhap As Date
            If Not Date.TryParse(ngayNhapStr, ngayNhap) Then
                MessageBox.Show("Ngày nhập không hợp lệ.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If

            Dim baoHanhStr As String = InputBox("Nhập thời gian bảo hành (tháng):")
            If Not IsNumeric(baoHanhStr) Then
                MessageBox.Show("Thời gian bảo hành phải là số nguyên.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            Dim baoHanh As Integer = Integer.Parse(baoHanhStr)

            Using conn As New SqlConnection(connectionString)
                conn.Open()
                Dim sql As String = "INSERT INTO DienThoai (TenDienThoai, HangSanXuat, GiaBan, SoLuongTon, MoTa, NgayNhap, BaoHanh)
                                 VALUES (@Ten, @Hang, @Gia, @SoLuong, @MoTa, @NgayNhap, @BaoHanh)"
                Using cmd As New SqlCommand(sql, conn)
                    cmd.Parameters.AddWithValue("@Ten", tenDT)
                    cmd.Parameters.AddWithValue("@Hang", hangSX)
                    cmd.Parameters.AddWithValue("@Gia", giaBan)
                    cmd.Parameters.AddWithValue("@SoLuong", soLuongTon)
                    cmd.Parameters.AddWithValue("@MoTa", moTa)
                    cmd.Parameters.AddWithValue("@NgayNhap", ngayNhap)
                    cmd.Parameters.AddWithValue("@BaoHanh", baoHanh)

                    cmd.ExecuteNonQuery()
                End Using
            End Using

            MessageBox.Show("Đã thêm điện thoại thành công!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information)
            LoadDienThoai() ' Cập nhật lại DataGridView

        Catch ex As Exception
            MessageBox.Show("Lỗi khi thêm điện thoại: " & ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnxoa_Click(sender As Object, e As EventArgs) Handles btnxoa.Click
        If dgvDienThoai.SelectedRows.Count = 0 Then
            MessageBox.Show("Vui lòng chọn một dòng để xóa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        ' Lấy mã điện thoại từ dòng được chọn
        Dim maDT As Integer = Convert.ToInt32(dgvDienThoai.SelectedRows(0).Cells("MaDienThoai").Value)

        ' Xác nhận xóa
        Dim result = MessageBox.Show("Bạn có chắc chắn muốn xóa điện thoại này?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If result = DialogResult.No Then Exit Sub

        Try
            Using conn As New SqlConnection(connectionString)
                conn.Open()
                Dim sql As String = "DELETE FROM DienThoai WHERE MaDienThoai = @MaDT"
                Using cmd As New SqlCommand(sql, conn)
                    cmd.Parameters.AddWithValue("@MaDT", maDT)
                    cmd.ExecuteNonQuery()
                End Using
            End Using

            MessageBox.Show("Đã xóa điện thoại thành công!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information)
            LoadDienThoai() ' Cập nhật lại DataGridView

        Catch ex As Exception
            MessageBox.Show("Lỗi khi xóa: " & ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class

﻿Imports System.Data.SqlClient

Public Class main
    Private connectionString As String = "Data Source=NGUYNTHNHNA4447\SA;Initial Catalog=bandienthoai;Persist Security Info=True;User ID=sa;Password=Konodioda2006@@;TrustServerCertificate=True"

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        quanlydienthoai.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try
            Dim tenKH As String = InputBox("Nhập tên khách hàng:")
            If tenKH = "" Then Exit Sub

            Dim sdt As String = InputBox("Nhập số điện thoại:")
            If sdt = "" Then Exit Sub

            Dim diaChi As String = InputBox("Nhập địa chỉ:")
            If diaChi = "" Then Exit Sub

            Dim maDTInput As String = InputBox("Nhập mã điện thoại:")
            If Not Integer.TryParse(maDTInput, Nothing) Then
                MessageBox.Show("Mã điện thoại không hợp lệ.")
                Exit Sub
            End If
            Dim maDT As Integer = Convert.ToInt32(maDTInput)

            Dim soLuongInput As String = InputBox("Nhập số lượng mua:")
            If Not Integer.TryParse(soLuongInput, Nothing) Then
                MessageBox.Show("Số lượng không hợp lệ.")
                Exit Sub
            End If
            Dim soLuong As Integer = Convert.ToInt32(soLuongInput)

            Using conn As New SqlConnection(connectionString)
                conn.Open()
                Dim sql As String = "INSERT INTO DonHang (TenKhachHang, SoDienThoai, DiaChi, MaDienThoai, SoLuong) 
                                 VALUES (@TenKH, @SDT, @DiaChi, @MaDT, @SoLuong)"
                Using cmd As New SqlCommand(sql, conn)
                    cmd.Parameters.AddWithValue("@TenKH", tenKH)
                    cmd.Parameters.AddWithValue("@SDT", sdt)
                    cmd.Parameters.AddWithValue("@DiaChi", diaChi)
                    cmd.Parameters.AddWithValue("@MaDT", maDT)
                    cmd.Parameters.AddWithValue("@SoLuong", soLuong)
                    cmd.ExecuteNonQuery()
                End Using
            End Using

            MessageBox.Show("Đơn hàng đã được thêm thành công!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show("Lỗi khi thêm đơn hàng: " & ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        lichsu.Show()
    End Sub
End Class